package com.demo.spring;

import org.springframework.boot.Banner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;

@SpringBootApplication
public class JdbcApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new SpringApplicationBuilder()
		.sources(JdbcApplication.class)
		.bannerMode(Banner.Mode.OFF)
		.run(args);
	}

}
