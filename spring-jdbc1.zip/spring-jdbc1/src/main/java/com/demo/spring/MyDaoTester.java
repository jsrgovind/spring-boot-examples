package com.demo.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class MyDaoTester implements CommandLineRunner {

	@Autowired
	HrService service;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println(service.registerEmp(108, "Sree", "Hyd", 50000));
		
		service.getEmpList().stream().forEach(e->System.out.println(e.getName()+"  "+e.getSalary()));

	}

}
