package com.lambda.demo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class LambdaDemo1 {

	public static void main(String[] args) {

		Thread t =new Thread(new Runnable() {
			@Override
			public void run() {
				System.out.println("Inside run...");
			}
		});
		t.start();
		
		Thread t2=new Thread(()->System.out.println("inside run with lambda..."));
		
		t2.start();

	
	
	
	List<String> names=Arrays.asList("John","James","Raju","Karthik","govind","Sree","Ram","santhu");
	
	names.stream().forEach(System.out::println);
	System.out.println("total count:"+names.stream().count());
	
	names.stream().filter(s->s.startsWith("S")).forEach(System.out::println);
	System.out.println(names.stream().filter(s->s.startsWith("J")).collect(Collectors.toList()));
	
	
	}
}
