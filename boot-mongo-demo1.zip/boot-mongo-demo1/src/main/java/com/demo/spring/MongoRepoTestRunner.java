package com.demo.spring;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;

@Component
public class MongoRepoTestRunner implements CommandLineRunner {

	@Autowired
	EmpMongoRepository emr;
	
	@Override
	public void run(String... args) throws Exception {
		emr.insert(new Emp(113,"sree","HYD",99000));
		
		//emr.findAll().stream().forEach(System.out::println);
		System.out.println("========================");
		Optional<Emp> op=emr.findById(114);
		System.out.println("========================");
		if(op.isPresent()) {
			System.out.println(op.get());
		}else {
			System.out.println("Emp not found");
		}
	}

}
