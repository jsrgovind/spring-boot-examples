package com.demo.spring;

import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;



@SpringBootApplication
public class BootRabbitmqDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootRabbitmqDemoApplication.class, args);
	}
	
	@Bean
	public RabbitTemplate rabbitTemplate(ConnectionFactory con) {
		return new RabbitTemplate(con);
	}

}
