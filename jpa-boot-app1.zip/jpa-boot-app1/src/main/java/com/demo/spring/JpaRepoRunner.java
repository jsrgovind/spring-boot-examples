package com.demo.spring;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;

@Component
public class JpaRepoRunner implements CommandLineRunner {

	@Autowired
	EmpRepositoy repo;
	
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("============================================");
		repo.findAll().stream().forEach(System.out::println);
		
		Optional<Emp> op= repo.findById(116);
		if(op.isPresent()) {
			System.out.println(op.get());
		}else {
			System.out.println("Emp not found!!!");
		}
		
	}

}
