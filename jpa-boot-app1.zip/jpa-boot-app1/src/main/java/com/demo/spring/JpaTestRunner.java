package com.demo.spring;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.demo.spring.entity.Emp;

@Component
@Transactional
public class JpaTestRunner implements CommandLineRunner {

	//@Autowired
	//EntityManagerFactory emf;
	@PersistenceContext
	EntityManager em;
		
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub

		//EntityManager em=emf.createEntityManager();
//		Emp e = new Emp(112,"Cris","Hyd",90000);
//		//em.persist(e);
		
		Emp e1=em.find(Emp.class, 111);
		System.out.println(e1);
		
		Query qry=em.createQuery("Select e from Emp e");
		qry.getResultList().stream().forEach(System.out::println);
	}

}
